/**
 * sim.c
 *
 * RISC-V 32-bit Instruction Level Simulator
 *
 * ECE 18-447
 * Carnegie Mellon University
 *
 * This is the core part of the simulator. The `process_instruction` function
 * will be invoked by the simulator each time it needs to simulate a single
 * processor cycle. This is responsible for simulating the next processor cycle.
 * This corresponds to simulating the next instruction, and updating the
 * register file, memory, and PC register appropriately as required by the next
 * instruction.
 *
 * This is where you can start add code and make modifications to implement the
 * rest of the instructions. You can add any additional files or change and
 * delete files as you need to implement the simulator, provided that they are
 * under the src directory. You may not change any files outside the src
 * directory. The only requirement is that you define a `process_instruction`
 * function with the same interface as below.
 *
 * The Makefile will automatically find any files you add, provided they are
 * under the src directory and have either a *.c or *.h extension. The files may
 * be nested in subdirectories under the src directory as well. Additionally,
 * the build system sets up the include paths so that you can place header files
 * in any subdirectory under the src directory, and include them from anywhere
 * else inside the src directory.
 **/

/*----------------------------------------------------------------------------*
 *  You may edit this file and add or change any files in the src directory.  *
 *----------------------------------------------------------------------------*/

// Standard Includes
#include <stdio.h>              // Printf and related functions
#include <stdbool.h>            // Boolean type and definitions

// 18-447 Simulator Includes
#include <riscv_isa.h>          // Definition of RISC-V opcodes, ISA registers
#include <riscv_abi.h>          // ABI registers and definitions
#include <sim.h>                // Definitions for the simulator
#include <memory.h>             // Interface to the processor memory
#include <register_file.h>      // Interface to the register file

/**
 * Simulates a single cycle on the CPU, updating the CPU's state as needed.
 *
 * This is the core part of the simulator. This simulates the current
 * instruction pointed to by the PC. This performs the necessary actions for the
 * instruction, and updates the CPU state appropriately.
 *
 * You implement this function.
 *
 * Inputs:
 *  - cpu_state     The current state of the CPU being simulated.
 *
 * Outputs:
 *  - cpu_state     The next state of the CPU being simulated. This function
 *                  updates the fields of the state as needed by the current
 *                  instruction to simulate it.
 **/


void process_instruction(cpu_state_t *cpu_state)
{
    // Fetch the 4-bytes for the current instruction
    uint32_t instr = mem_read32(cpu_state, cpu_state->pc);

    // Decode the opcode, 7-bit function code, and registers
    opcode_t opcode = instr & 0x7F;
    funct7_t funct7 = (instr >> 25) & 0x7F;
    riscv_isa_reg_t rs1 = (instr >> 15) & 0x1F;
    riscv_isa_reg_t rs2 = (instr >> 20) & 0x1F;
    riscv_isa_reg_t rd = (instr >> 7) & 0x1F;

    /* Decode the instruction as an I-type instruction, sign extending the
     * immediate value. */
    itype_int_funct3_t itype_funct3 = (instr >> 12) & 0x7;
    int32_t itype_imm = ((int32_t)instr) >> 20;

    // Decode the instruction as an R-type instruction
    rtype_funct3_t rtype_funct3 = (instr >> 12) & 0x7;

    // Decode the instruction as an S-type instruction
    stype_funct3_t stype_funct3 = (instr >> 12) & 0x7;

    //get the immediate value of S-type
    uint32_t imm = ((instr >> 7)&0x1f) |
                        ((instr >> 20)&0xfe0);
    imm = imm << 20;
    int32_t stype_imm = ((signed)imm) >> 20;


    //get the immediate value of J-type
    uint32_t jimm = ((instr >> 20)&0x7fe) |
                    ((instr >> 9)&0x800) |
                    ((instr)&0xff000) |
                    ((instr >> 11)&0x100000);
    
    jimm = jimm << 11;
    int32_t jtype_imm = (((signed)jimm) >> 11) & 0xfffffffe;

    // Decode the instruction as an SB-type instruction
    sbtype_funct3_t sbtype_funct3 = (instr >> 12) & 0x7;

    //get the immediate value of SB-type
    int32_t btype_imm = 
      (((int32_t)(instr&0x80000000)) >> 19) |
      ((instr&0x7e000000) >> 20) |
      ((instr&0x80) << 4) |
      ((instr&0xf00) >> 7) ;

    //get the immediate value of U-type
    int32_t utype_imm = ((int32_t)instr) >> 12;

    // Decode the 12-bit function code for system instructions
    itype_funct12_t sys_funct12 = (instr >> 20) & 0xFFF;

    switch (opcode)
    {
        // General R-Type arithmetic operation
        case OP_OP: {
            switch (rtype_funct3)
            {
                // 3-bit function code for add or subtract
                case FUNCT3_ADD_SUB: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t sum = register_read(cpu_state, rs1) +
                                    register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, sum);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }
                        
                        //SUB
                        case FUNCT7_ALT_INT:{
                            uint32_t res = register_read(cpu_state, rs1) -
                                    register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        //MUL
                        case FUNCT7_MULDIV: {
                            uint32_t product = register_read(cpu_state, rs1) *
                                    register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, product);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;
                        }
                    }
                    break;
                }

                //shift left logical
                case FUNCT3_SLL: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t res = register_read(cpu_state, rs1) <<
                                    register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                // Set if Less Than
                case FUNCT3_SLT: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            int32_t first = register_read(cpu_state, rs1);
                            int32_t second = register_read(cpu_state, rs2);
                            if (first < second){
                                register_write(cpu_state, rd, 1);
                            }
                            else{
                                register_write(cpu_state, rd, 0);
                            }
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                // Set if Less Than Unsigned
                case FUNCT3_SLTU: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t first = register_read(cpu_state, rs1);
                            uint32_t second = register_read(cpu_state, rs2);
                            if (first < second){
                                register_write(cpu_state, rd, 1);
                            }
                            else{
                                register_write(cpu_state, rd, 0);
                            }
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                // XOR
                case FUNCT3_XOR: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t res = register_read(cpu_state, rs1) ^ register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                case FUNCT3_SRL_SRA: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        //Shift right logical
                        case FUNCT7_INT: {
                            uint32_t first = register_read(cpu_state, rs1);
                            uint32_t second = register_read(cpu_state, rs2);
                            //use bit operations to zero-extend the result
                            uint32_t res = first >> second;
                            if(second == 0){
                                res = first;
                            }
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        //Shift right Arithmatic
                        case FUNCT7_ALT_INT: {
                            int32_t first = (signed)register_read(cpu_state, rs1);
                            int32_t second = (signed)register_read(cpu_state, rs2);
                            int32_t res = first >> second;
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                //OR
                case FUNCT3_OR: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t first = register_read(cpu_state, rs1);
                            uint32_t second = register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, (first | second));
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                //AND
                case FUNCT3_AND: {
                    switch (funct7)
                    {
                        // 7-bit function code for typical integer instructions
                        case FUNCT7_INT: {
                            uint32_t first = register_read(cpu_state, rs1);
                            uint32_t second = register_read(cpu_state, rs2);
                            register_write(cpu_state, rd, (first & second));
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        }
                    }
                    break;
                }

                default: {
                    fprintf(stderr, "Encountered unknown/unimplemented "
                            "3-bit rtype function code 0x%01x. Halting "
                            "simulation.\n",
                            rtype_funct3);
                    cpu_state->halted = true;
                    break;
                }
            }
            break;
        }
	    
        case OP_IMM: {
            switch (itype_funct3)
            {
                // 3-bit function code for ADDI
                case FUNCT3_ADDI: {
                    uint32_t sum = register_read(cpu_state, rs1) + itype_imm;
                    register_write(cpu_state, rd, sum);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for SLTI
                case FUNCT3_SLTI: {
                    int32_t imm = (signed) itype_imm;
                    int32_t first = (signed) register_read(cpu_state, rs1);
                    if (first < imm){
                        register_write(cpu_state, rd, 1);
                    }
                    else{
                        register_write(cpu_state, rd, 0);
                    }
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for SLTIU
                case FUNCT3_SLTIU: {
                    uint32_t first = register_read(cpu_state, rs1);
                    if (first < (unsigned)itype_imm){
                        register_write(cpu_state, rd, 1);
                    }
                    else{
                        register_write(cpu_state, rd, 0);
                    }
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for XORI
                case FUNCT3_XORI: {
                    uint32_t first = register_read(cpu_state, rs1);
                    uint32_t res = first ^ (unsigned)itype_imm;
                    register_write(cpu_state, rd, res);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for ORI
                case FUNCT3_ORI: {
                    uint32_t first = register_read(cpu_state, rs1);
                    uint32_t res = first | (unsigned)itype_imm;
                    register_write(cpu_state, rd, res);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for ANDI
                case FUNCT3_ANDI: {
                    uint32_t first = register_read(cpu_state, rs1);
                    uint32_t res = first & (unsigned)itype_imm;
                    register_write(cpu_state, rd, res);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for SLLI
                case FUNCT3_SLLI: {
                    uint32_t first = register_read(cpu_state, rs1);
                    uint32_t res = first << (unsigned)itype_imm;
                    register_write(cpu_state, rd, res);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                // 3-bit function code for SRLI and SRAI
                case FUNCT3_SRLI_SRAI: {
                    switch(funct7){
                        // 7-bit function code for typical integer instructions
                        //SRLI
                        case FUNCT7_INT: {
                            uint32_t first = register_read(cpu_state, rs1);
                            uint32_t second = (uint32_t)itype_imm;
                            //bitwise operation to zero-extend the result 
                            uint32_t res = first >> second;
                            if(second == 0){
                                res = first;
                            }
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        //SRAI
                        case FUNCT7_ALT_INT: {
                            int32_t first = (signed)register_read(cpu_state, rs1);
                            int32_t second = itype_imm;
                            int32_t res = first >> second;
                            register_write(cpu_state, rd, res);
                            cpu_state->pc = cpu_state->pc + sizeof(instr);
                            break;
                        }

                        default: {
                            fprintf(stderr, "Encountered unknown/unimplemented "
                                    "7-bit function code 0x%01x. Halting "
                                    "simulation.\n", funct7);
                            cpu_state->halted = true;
                            break;     
                        } 
                    }
                    break;
                }

                default: {
                    fprintf(stderr, "Encountered unknown/unimplemented 3-bit "
                            "itype function code 0x%01x. Halting simulation.\n",
                            itype_funct3);
                    cpu_state->halted = true;
                    break;
                }
            }
            break;
        }

        // Load operation
        case OP_LOAD: {
            switch (itype_funct3)
            {
                //Load Word
                case FUNCT3_LW: {
                    uint32_t maddress = register_read(cpu_state, rs1) + itype_imm;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t mdata=mem_read32(cpu_state, maddress);
                    register_write(cpu_state, rd, mdata);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //load byte
                case FUNCT3_LB: {
                    uint32_t maddress = register_read(cpu_state, rs1) + itype_imm;
                    //offset to get the correct byte
                    int32_t offset = (maddress & 0x3) << 3;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t mdata=mem_read32(cpu_state, maddress);

                    //get the desired byte and sign extend it
                    mdata = (mdata >> offset) & 0xFF;
                    int32_t data = (((int8_t)mdata) << 24) >> 24;
                    register_write(cpu_state, rd, data);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //load halfword
                case FUNCT3_LH: {
                    uint32_t maddress = register_read(cpu_state, rs1) + itype_imm;
                    //offset to get the correct byte
                    int32_t offset = (maddress & 0x3) << 3;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t mdata=mem_read32(cpu_state, maddress);

                    //get the desired halfword and sign extend it
                    mdata = (mdata >> offset) & 0xFFFF;
                    int32_t data = (((int32_t)mdata) << 16) >> 16;
                    register_write(cpu_state, rd, data);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //load byte unsigned
                case FUNCT3_LBU: {
                    uint32_t maddress = register_read(cpu_state, rs1) + itype_imm;
                    //offset to get the correct byte
                    int32_t offset = (maddress & 0x3) << 3;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t mdata=mem_read32(cpu_state, maddress);
                    //get the desired byte
                    mdata = (mdata >> offset) & 0xFF;
                    register_write(cpu_state, rd, mdata);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //load halfword unsigned
                case FUNCT3_LHU: {
                    uint32_t maddress = register_read(cpu_state, rs1) + itype_imm;
                    
                    //offset to get the correct byte
                    int32_t offset = (maddress & 0x3) << 3;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t mdata=mem_read32(cpu_state, maddress);
                    fprintf(stderr,"data is %x\n",mdata);
                    
                    //get the desired halfword
                    mdata = (mdata >> offset) & 0xFFFF;
                    register_write(cpu_state, rd, mdata);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                default: {
                    fprintf(stderr, "Encountered unknown/unimplemented 3-bit "
                            "itype function code 0x%01x. Halting simulation.\n",
                            itype_funct3);
                    cpu_state->halted = true;
                    break;
                }
            }
            break;
        }

        case OP_STORE: {
            switch (stype_funct3)
            {
                //store word
                case FUNCT3_SW: {
                    uint32_t maddress = register_read(cpu_state, rs1) + stype_imm;
                    //address alignment operation
                    maddress = maddress & 0xFFFFFFFC;
                    uint32_t value = register_read(cpu_state, rs2);
                    mem_write32(cpu_state, maddress, value);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //store byte
                case FUNCT3_SB: {
                    uint32_t maddress = register_read(cpu_state, rs1) + stype_imm;
                    //offset to get the correct byte
                    int32_t offset = (maddress & 0x3) << 3;
                    //address alignment operation
                    maddress = (maddress & 0xFFFFFFFC);

                    uint32_t value = register_read(cpu_state, rs2);
                    uint32_t ori_value = mem_read32(cpu_state, maddress);
                    //mask to clear the original byte
                    uint32_t sb_mask = ~(0xFF << offset);

                    //update the word to store the new byte in
                    value = ((value & 0xFF) << offset) + 
                            (ori_value & sb_mask);
                    mem_write32(cpu_state, maddress, value);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                //store halfword
                case FUNCT3_SH: {
                    uint32_t maddress = register_read(cpu_state, rs1) 
                                        + stype_imm;

                    //offset to get the correct byte                    
                    int32_t offset = (maddress & 0x3) << 3;
                    
                    //address alignment operation
                    maddress = (maddress & 0xFFFFFFFC);
                    uint32_t value = register_read(cpu_state, rs2);
                    uint32_t ori_value = mem_read32(cpu_state, maddress);

                    //mask to clear the original halfword
                    uint32_t sh_mask = ~(0xFFFF << offset);

                    //update the word to store the new halfword in
                    value = ((value & 0xFFFF) << offset) + 
                             (ori_value & sh_mask);
                    mem_write32(cpu_state, maddress, value);
                    cpu_state->pc = cpu_state->pc + sizeof(instr);
                    break;
                }

                default: {
                    fprintf(stderr, "Encountered unknown/unimplemented 3-bit "
                            "itype function code 0x%01x. Halting simulation.\n",
                            itype_funct3);
                    cpu_state->halted = true;
                    break;
                }
            }
            break;
        }

        //Load Unsigned immediate
        case OP_LUI: {
            int32_t immi = utype_imm << 12;
            register_write(cpu_state, rd, immi);
            cpu_state->pc = cpu_state->pc + sizeof(instr);
            break;
        }

        //Add Unsigned Immediate to PC
        case OP_AUIPC: {
            int32_t immi = ((int32_t)utype_imm) << 12;
            int32_t res = immi + (int32_t) (cpu_state->pc);
            register_write(cpu_state, rd, res);
            cpu_state->pc = cpu_state->pc + sizeof(instr);
            break;
        }

        //jump and link
        case OP_JAL: {
            int32_t target = cpu_state->pc + jtype_imm;
            register_write(cpu_state, rd, 
                          (cpu_state->pc + sizeof(instr)));
            cpu_state->pc = target;
            break;
        }

        //jump and Link Register
        case OP_JALR: {
            int32_t target = register_read(cpu_state, rs1) + ((int32_t)itype_imm);
            //address alignment
            target = target & 0xfffffffe;
            register_write(cpu_state, rd, 
                          (cpu_state->pc + sizeof(instr)));
            cpu_state->pc = target;
            break;
        }
	
        // SB-type branch instruction
        case OP_BRANCH: {
      //switch on sbtype
	  switch (sbtype_funct3) 
	  {
        //branch if equal
	    case FUNCT3_BEQ: {
	      if (register_read(cpu_state, rs1) ==
		    register_read(cpu_state, rs2)) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }

        //branch if not equal
        case FUNCT3_BNE: {
          if (register_read(cpu_state, rs1) !=
		      register_read(cpu_state, rs2)) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }

        //branch if less than
        case FUNCT3_BLT: {
          if (((signed)register_read(cpu_state, rs1)) <
		      ((signed)register_read(cpu_state, rs2))) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }

        //branch if greater or equal to 
        case FUNCT3_BGE: {
          if (((signed)register_read(cpu_state, rs1)) >=
		      ((signed)register_read(cpu_state, rs2))) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }

        //brach if less than (unsigned)
        case FUNCT3_BLTU: {
          if ((register_read(cpu_state, rs1)) <
		      (register_read(cpu_state, rs2))) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }

        //brach if greater than or equal to (unsigned)
        case FUNCT3_BGEU: {
          if ((register_read(cpu_state, rs1)) >=
		      (register_read(cpu_state, rs2))) {
		      cpu_state->pc += btype_imm;
	      } 
          else {
		      cpu_state->pc += sizeof(uint32_t);
	      }
	      break;
        }
        
        default: {
            fprintf(stderr, "Encountered unknown/unimplemented "
                  "3-bit rtype function code 0x%01x. Halting "
                  "simulation.\n",
                  sbtype_funct3);
            cpu_state->halted = true;
            break;
	    } 
      }
        break;
	}

        // General system operation
        case OP_SYSTEM: {
            switch (sys_funct12)
            {
                // 12-bit function code for ECALL
                case FUNCT12_ECALL: {
                    //read value from register A0
                    uint32_t a0_value = register_read(cpu_state, REG_A0);

                    if (a0_value == ECALL_ARG_HALT) {
                        fprintf(stdout, "ECALL invoked with halt argument, "
                                "halting the simulator.\n");
                        cpu_state->halted = true;
                    }
                    else{
                        cpu_state->pc += sizeof(uint32_t);
                    }
                    break;
                }

                default: {
                    fprintf(stderr, "Encountered unknown/unimplemented 12-bit "
                            "system function code 0x%03x. Halting "
                            "simulation.\n", sys_funct12);
                    cpu_state->halted = true;
                    break;
                }
            }
            break;
        }

        default: {
            fprintf(stderr, "Encountered unknown opcode 0x%02x. Halting "
                    "simulation.\n", opcode);
            cpu_state->halted = true;
            break;
        }
    }

    return;
}
