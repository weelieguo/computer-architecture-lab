int main(){
  int sum = 0;

  for(int i = 0; i < 3; i++){
    sum++;
  }
  return sum;
}
