int add(int a){
  if(a == 2) return a;
  else return add(a+1);
}


int main(){
  int b = add(0);
  return b;
  
}
